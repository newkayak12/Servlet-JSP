package com.admin.controller;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import com.admin.model.service.*;
import com.member.model.vo.*;

/**
 * Servlet implementation class MemberList
 */
@WebServlet("/memberList.admin")
public class MemberList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//관리자 아닌 사람 접근에 예외처리
		HttpSession session = request.getSession(false);
		Member loginMember = (Member) session.getAttribute("loginMember");
				if((session == null) || loginMember== null || !loginMember.getUserId().equals("admin")){
					
//					잘못된 접근입니다.
					request.setAttribute("msg", "잘못된 접근입니다.");
					request.setAttribute("loc", "/");
					
					request.getRequestDispatcher("/views/common/msg.jsp").forward(request, response);
					
					
					
				} else {
		
		
		
		
		
					List<Member> result = new AdminService().showAllMember();
					request.setAttribute("list", result);
					
					
					request.getRequestDispatcher("/views/admin/memberlist.jsp").forward(request, response);
					//도착 페이지?
					
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
