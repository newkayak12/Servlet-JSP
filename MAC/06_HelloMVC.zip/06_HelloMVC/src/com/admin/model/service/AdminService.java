package com.admin.model.service;


import static com.common.JDBCTemplate.*;

import java.sql.*;
import java.util.*;

import com.admin.model.dao.*;
import com.member.model.vo.*;

public class AdminService {

	private AdminDao dao = new AdminDao();
	private Connection conn = null;
	
	public List<Member> showAllMember() {
		
		conn = getConnection();
		
		List<Member> result = dao.showAllMember(conn);
		
		close(conn);
		
		
		return  result;
	}
}
