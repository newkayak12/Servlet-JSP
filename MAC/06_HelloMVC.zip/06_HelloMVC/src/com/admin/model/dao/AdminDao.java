package com.admin.model.dao;

import java.io.*;
import java.sql.*;
import java.util.*;

import com.common.*;
import com.member.model.vo.*;

public class AdminDao {
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private Properties prop = new Properties();
	
	
	public AdminDao() {
	
		try {
			String filePath=AdminDao.class.getResource("/sql/admin_sql.properties").getPath();
			prop.load(new FileReader(filePath));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
			
	
	
	public List<Member> showAllMember(Connection conn) {
		List<Member> result = new ArrayList();
		Member m = null;
			try {
				pstmt = conn.prepareStatement(prop.getProperty("admin_showAll"));
				rs = pstmt.executeQuery();
				
					while(rs.next()){
						
						//조회된 row가 있다
						m=new Member();
						m.setUserId(rs.getString("userid"));
						m.setPassword(rs.getString("password"));
						m.setUserName(rs.getString("username"));
						m.setAge(rs.getInt("age"));
						//char형으로 데이터를 받을 때 사용
						//m.setGender(rs.getString("gender").charAt(0));
						m.setGender(rs.getString("gender"));
						
						String email = null;
							try {
								
								
								email = AESCryptor.decrypt(rs.getString("email"));
								
								
							} catch (Exception e) {
								
								email  = rs.getString("email");
							}
						
						
						m.setEmail(email);
						
						String phone = null;
							try {
								
								
								phone = AESCryptor.decrypt(rs.getString("phone"));
								
								
							} catch (Exception e) {
								
								phone  = rs.getString("phone");
							}
							
						
						m.setPhone(phone);
						
						m.setAddress(rs.getString("address"));
						m.setHobby(rs.getString("hobby"));
						m.setEnrollDate(rs.getDate("enrolldate"));
						
						result.add(m);
						
						
					}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		
		
		
		return result;
	}

}
